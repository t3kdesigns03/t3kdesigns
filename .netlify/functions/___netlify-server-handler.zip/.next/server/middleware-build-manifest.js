globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/YnojeUhXbGRyjd-jqV5u_/_buildManifest.js",
    "static/YnojeUhXbGRyjd-jqV5u_/_ssgManifest.js",
    "static/YnojeUhXbGRyjd-jqV5u_/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/0ufyxag_pxqbt.js",
    "static/chunks/27t_qfc-3_lzs.js",
    "static/chunks/3t8csva4ooglv.js",
    "static/chunks/turbopack-12opkq8ntawed.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
